# MancsBot KITT – Android APK wrapper

Androidos, teljes képernyős WebView-csomag a meglévő KITT / MancsBot React dashboardhoz.

## Beépített Android funkciók

- Mobilra csomagolt meglévő React/Vite `dist` felület.
- Indítóképernyő:
  - **Készítette: Nagy Dániel**
  - **© 2026 Nagy Dániel. Minden jog fenntartva.**
  - Engedély nélküli másolásra, módosításra és terjesztésre vonatkozó jogvédelmi szöveg.
- Jobb alsó **⚙** gomb: Node/Express backend címének beállítása.
- HTTP LAN backend engedélyezve (pl. `http://192.168.1.20:3000`).
- HTTPS backend is használható.
- A meglévő `/api/bot/*` hívások automatikusan a beállított backend címre mennek.
- Backup letöltési endpoint kezelése.

## Fontos architekturális megjegyzés

A dashboard Android APK-ban fut, de a jelenlegi kereskedési motor Node.js/Express alapú. Ezért a valódi KITT engine-t külön kell futtatni (PC-n, szerveren vagy Termuxban), és az APK-ban a ⚙ gombbal meg kell adni a címét.

**A `.env`, Coinbase kulcsok és egyéb titkok nincsenek és ne is legyenek beépítve az APK-ba.**

## Android Studio build

1. Nyisd meg ezt a mappát Android Studioban.
2. Várd meg a Gradle sync-et.
3. `Build > Build APK(s)`.
4. Debug APK helye: `app/build/outputs/apk/debug/app-debug.apk`.

Követelmény: Android SDK 35, JDK 17+.

## GitHub Actions – APK Android Studio nélkül

A `.github/workflows/build-apk.yml` workflow feltöltés után automatikusan elkészíti a debug APK-t. A GitHub repo `Actions` fülén a futás artifactjai között lesz `MancsBot-KITT-debug-apk` néven.

## Backend indítás

Az eredeti projekt `coinbase-paper-trader` mappájában:

```bash
npm install
npm start
```

Ezután az APK ⚙ beállításában add meg a szervert, például:

```text
http://192.168.1.20:3000
```

Telefonról LAN címet használj, ne `localhost`-ot, ha a backend másik gépen fut.

import { useCallback, useEffect, useMemo, useState } from 'react'

const API = '/api/bot' // Android wrapper rewrites /api/* requests to the configured backend

const NAV = [
  ['overview', 'Overview', '⌂'],
  ['market', 'Market Radar', '◈'],
  ['portfolio', 'Portfolio', '▣'],
  ['strategy', 'Strategy Core', '⚡'],
  ['trades', 'Trades', '↗'],
  ['diagnostics', 'Diagnostics', '◇'],
  ['backup', 'Backup', '↻'],
]

const money = (n, digits = 2) => `$${Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits })}`
const pct = (n) => `${Number(n || 0) >= 0 ? '+' : ''}${Number(n || 0).toFixed(2)}%`
const time = (iso) => iso ? new Date(iso).toLocaleTimeString('hu-HU', { hour12: false }) : '—'

function Sparkline({ values = [] }) {
  const nums = values.filter(Number.isFinite)
  if (nums.length < 2) return <div className="spark-empty">waiting for feed</div>
  const min = Math.min(...nums), max = Math.max(...nums), range = max - min || 1
  const points = nums.map((v, i) => `${(i / (nums.length - 1)) * 100},${100 - ((v - min) / range) * 88 - 6}`).join(' ')
  return <svg className="spark" viewBox="0 0 100 100" preserveAspectRatio="none"><polyline points={points} fill="none" vectorEffect="non-scaling-stroke" /></svg>
}

function App() {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)
  const [page, setPage] = useState('overview')
  const [priceHistory, setPriceHistory] = useState({})
  const [notice, setNotice] = useState('')

  const refresh = useCallback(async () => {
    try {
      const res = await fetch(`${API}/status`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const json = await res.json()
      setData(json)
      setError(null)
      setPriceHistory(prev => {
        const next = { ...prev }
        Object.entries(json.lastPrices || {}).forEach(([pair, value]) => {
          next[pair] = [...(prev[pair] || []), Number(value)].slice(-48)
        })
        return next
      })
    } catch (err) {
      setError('A backend nem elérhető. Indítsd el a Node szervert a 3000-es porton.')
    }
  }, [])

  useEffect(() => {
    refresh()
    const id = setInterval(refresh, 2000)
    return () => clearInterval(id)
  }, [refresh])

  const action = async (endpoint, body = null) => {
    setLoading(true); setNotice('')
    try {
      const opts = { method: 'POST', headers: { 'Content-Type': 'application/json' } }
      if (body) opts.body = JSON.stringify(body)
      const res = await fetch(`${API}/${endpoint}`, opts)
      const json = await res.json()
      if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`)
      if (json.state) setData(json.state)
      setNotice(endpoint === 'start' ? 'KITT engine started.' : endpoint === 'stop' ? 'KITT engine stopped.' : endpoint === 'reset' ? 'Paper session reset.' : `${body?.side || ''} order executed.`)
    } catch (err) { setError(err.message) }
    finally { setLoading(false) }
  }

  const portfolio = useMemo(() => {
    const pv = Number(data?.portfolioValue || 0), initial = Number(data?.initialBalance || 0)
    return { pv, initial, pnl: Number(data?.pnl || pv - initial), pnlPct: Number(data?.pnlPercent || 0) }
  }, [data])

  const pairs = data?.lastPrices ? Object.keys(data.lastPrices) : []
  const trades = [...(data?.trades || [])].reverse()
  const logs = [...(data?.logs || [])].reverse()
  const positions = data?.positions || {}
  const stats = data?.strategyStats || {}

  if (!data && !error) return <div className="boot"><div className="boot-mark">K</div><strong>KITT CORE</strong><span>Initializing command center…</span></div>

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-orb">K</div><div><strong>KITT</strong><small>TRADING OS</small></div></div>
        <div className="side-label">COMMAND CENTER</div>
        <nav>{NAV.map(([id, label, icon]) => <button key={id} className={page === id ? 'nav-item active' : 'nav-item'} onClick={() => setPage(id)}><span>{icon}</span>{label}</button>)}</nav>
        <div className="sidebar-bottom">
          <div className="mini-status"><span className="live-dot" />{data?.running ? 'ENGINE ACTIVE' : 'ENGINE STANDBY'}<b>{data?.paperTrade ? 'PAPER' : 'LIVE'}</b></div>
          <div className="version">KITT Dashboard v2.0 · 2026</div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div><span className="eyebrow">MancsBot / Command Center</span><h1>{NAV.find(x => x[0] === page)?.[1]}</h1></div>
          <div className="top-actions"><div className="feed-chip"><span className="live-dot" />MARKET FEED <b>LIVE</b></div><div className="mode-chip">{data?.paperTrade ? 'PAPER MODE' : 'LIVE MODE'}</div></div>
        </header>

        {error && <div className="alert error">⚠ {error}<button onClick={refresh}>Retry</button></div>}
        {notice && <div className="alert success">✓ {notice}</div>}

        {page === 'overview' && <Overview data={data} portfolio={portfolio} pairs={pairs} stats={stats} positions={positions} trades={trades} priceHistory={priceHistory} loading={loading} action={action} />}
        {page === 'market' && <Market data={data} pairs={pairs} stats={stats} priceHistory={priceHistory} action={action} loading={loading} />}
        {page === 'portfolio' && <Portfolio data={data} portfolio={portfolio} positions={positions} pairs={pairs} />}
        {page === 'strategy' && <Strategy data={data} stats={stats} />}
        {page === 'trades' && <Trades trades={trades} />}
        {page === 'diagnostics' && <Diagnostics data={data} logs={logs} />}
        {page === 'backup' && <Backup />}
      </main>
    </div>
  )
}

function StatCard({ label, value, sub, tone = '' }) { return <div className="stat-card"><span>{label}</span><strong className={tone}>{value}</strong><small>{sub}</small></div> }

function Overview({ data, portfolio, pairs, stats, positions, trades, priceHistory, loading, action }) {
  const invested = pairs.reduce((sum, p) => sum + Number(positions[p]?.amount || 0) * Number(data?.lastPrices?.[p] || 0), 0)
  return <>
    <section className="hero-grid">
      <div className="hero-card"><div className="card-kicker">TOTAL PORTFOLIO</div><div className="hero-value">{money(portfolio.pv)}</div><div className={portfolio.pnl >= 0 ? 'hero-pnl positive' : 'hero-pnl negative'}>{pct(portfolio.pnlPct)} <span>({money(portfolio.pnl)})</span></div><div className="hero-chart"><Sparkline values={Object.values(priceHistory).flat().slice(-80)} /></div></div>
      <div className="control-card"><div className="card-kicker">KITT ENGINE CONTROL</div><div className="engine-state"><span className={data?.running ? 'pulse on' : 'pulse'} />{data?.running ? 'ENGINE RUNNING' : 'ENGINE STANDBY'}</div><div className="control-meta"><span>Strategy <b>{data?.strategyName || 'Adaptive'}</b></span><span>Mode <b>{data?.paperTrade ? 'Paper' : 'Live'}</b></span></div><div className="control-buttons">{!data?.running ? <button className="primary" onClick={() => action('start')} disabled={loading}>▶ Start engine</button> : <button className="danger" onClick={() => action('stop')} disabled={loading}>■ Stop engine</button>}<button className="ghost" onClick={() => action('reset')} disabled={loading}>↻ Reset</button></div></div>
    </section>
    <section className="stat-grid"><StatCard label="CASH BALANCE" value={money(data?.cash)} sub="Available capital" /><StatCard label="INVESTED" value={money(invested)} sub="Current market value" /><StatCard label="TRADES" value={data?.trades?.length || 0} sub="Session executions" /><StatCard label="FEED" value={data?.feedStats?.connected ? 'CONNECTED' : 'WAITING'} sub={`${data?.feedStats?.ticks || 0} ticks received`} tone={data?.feedStats?.connected ? 'positive' : ''} /></section>
    <section className="section-head"><div><span className="eyebrow">LIVE MARKET</span><h2>Market Radar</h2></div><button className="link-button" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>Auto refresh · 2s</button></section>
    <div className="market-grid">{pairs.map(pair => <MarketCard key={pair} pair={pair} price={data.lastPrices[pair]} stats={stats[pair]} history={priceHistory[pair]} />)}</div>
    <section className="lower-grid"><div className="panel"><div className="panel-head"><div><span className="eyebrow">EXECUTION STREAM</span><h2>Recent Trades</h2></div><span className="count-pill">{trades.length}</span></div><TradeRows trades={trades.slice(0, 6)} /></div><div className="panel"><div className="panel-head"><div><span className="eyebrow">SYSTEM INTELLIGENCE</span><h2>Strategy Core</h2></div></div><StrategySummary data={data} stats={stats} /></div></section>
  </>
}

function MarketCard({ pair, price, stats, history }) { const rsi = stats?.rsi; return <div className="market-card"><div className="market-top"><div className="coin"><span className="coin-icon">{pair.slice(0, 1)}</span><div><strong>{pair.replace('-USD', '')}</strong><small>{pair}</small></div></div><span className="signal">{rsi == null ? 'WAIT' : rsi < 35 ? 'BUY ZONE' : rsi > 68 ? 'SELL ZONE' : 'HOLD'}</span></div><div className="market-price">{money(price, price < 10 ? 4 : 2)}</div><div className="market-meta"><span>RSI <b>{rsi == null ? '—' : rsi.toFixed(1)}</b></span><span>Trend <b>{stats?.change == null ? '—' : pct(stats.change * 100)}</b></span></div><div className="market-spark"><Sparkline values={history} /></div></div> }

function StrategySummary({ data, stats }) { const entries = Object.entries(stats); return <div className="strategy-summary"><div className="strategy-banner"><div className="strategy-icon">⚡</div><div><strong>{data?.strategyName || 'Adaptive'}</strong><small>Dynamic decision engine</small></div><span className="active-tag">ACTIVE</span></div>{entries.slice(0, 5).map(([pair, s]) => <div className="decision-row" key={pair}><span>{pair.replace('-USD', '')}</span><div className="decision-bar"><i style={{ width: `${Math.min(100, Math.max(0, Number(s?.rsi || 50)))}%` }} /></div><b>{s?.rsi == null ? '—' : `RSI ${s.rsi.toFixed(1)}`}</b></div>)}</div> }

function TradeRows({ trades }) { return trades.length ? <div className="trade-list">{trades.map(t => <div className="trade-row" key={t.id}><div className={`side-badge ${t.side.toLowerCase()}`}>{t.side}</div><div><strong>{t.productId}</strong><small>{time(t.time)}</small></div><div className="trade-number">{money(t.price)}</div><div className="trade-number">{money(t.value)}</div></div>)}</div> : <Empty text="No trades executed in this session." /> }
function Empty({ text }) { return <div className="empty">{text}</div> }

function Market({ data, pairs, stats, priceHistory, action, loading }) { return <div className="page-stack"><div className="page-intro"><span className="eyebrow">LIVE TICKER MATRIX</span><p>Real-time Coinbase market feed with strategy context.</p></div><div className="market-grid market-large">{pairs.map(pair => <div key={pair} className="market-card large"><MarketCard pair={pair} price={data.lastPrices[pair]} stats={stats[pair]} history={priceHistory[pair]} /><div className="force-actions"><button onClick={() => action('force-trade', { productId: pair, side: 'BUY' })} disabled={loading}>BUY</button><button onClick={() => action('force-trade', { productId: pair, side: 'SELL' })} disabled={loading}>SELL</button></div></div>)}</div></div> }

function Portfolio({ data, portfolio, positions, pairs }) { return <div className="page-stack"><div className="stat-grid"><StatCard label="EQUITY" value={money(portfolio.pv)} sub="Current portfolio value" /><StatCard label="P&L" value={money(portfolio.pnl)} sub={pct(portfolio.pnlPct)} tone={portfolio.pnl >= 0 ? 'positive' : 'negative'} /><StatCard label="CASH" value={money(data?.cash)} sub="Unallocated balance" /><StatCard label="INITIAL" value={money(portfolio.initial)} sub="Session starting value" /></div><div className="panel"><div className="panel-head"><div><span className="eyebrow">POSITION BOOK</span><h2>Open Positions</h2></div></div><div className="position-table"><div className="table-head"><span>Asset</span><span>Quantity</span><span>Avg. Price</span><span>Market Price</span><span>Value</span></div>{pairs.map(pair => { const p = positions[pair] || {}; const value = Number(p.amount || 0) * Number(data?.lastPrices?.[pair] || 0); return <div className="table-row" key={pair}><strong>{pair}</strong><span>{Number(p.amount || 0).toFixed(8)}</span><span>{money(p.avgPrice)}</span><span>{money(data?.lastPrices?.[pair])}</span><b>{money(value)}</b></div> })}</div></div></div> }

function Strategy({ data, stats }) { return <div className="page-stack"><div className="strategy-header"><div className="strategy-big-icon">⚡</div><div><span className="eyebrow">ACTIVE DECISION ENGINE</span><h2>{data?.strategyName || 'Adaptive'}</h2><p>Strategy telemetry from the live price stream.</p></div><span className="active-tag">RUNNING</span></div><div className="diagnostic-grid">{Object.entries(stats).map(([pair, s]) => <div className="panel strategy-detail" key={pair}><div className="panel-head"><h2>{pair}</h2><span className="count-pill">LIVE</span></div><div className="metric-list"><Metric label="Current price" value={money(s?.current)} /><Metric label="RSI" value={s?.rsi == null ? '—' : s.rsi.toFixed(2)} /><Metric label="Average" value={s?.avg == null ? '—' : money(s.avg)} /><Metric label="Change" value={s?.change == null ? '—' : pct(s.change * 100)} /><Metric label="Dynamic threshold" value={s?.dynamicThreshold == null ? '—' : `${(s.dynamicThreshold * 100).toFixed(3)}%`} /></div></div>)}</div></div> }
function Metric({ label, value }) { return <div className="metric"><span>{label}</span><b>{value}</b></div> }

function Trades({ trades }) { return <div className="page-stack"><div className="panel"><div className="panel-head"><div><span className="eyebrow">EXECUTION LEDGER</span><h2>Trade History</h2></div><span className="count-pill">{trades.length} RECORDS</span></div><div className="position-table"><div className="table-head trade-cols"><span>Time</span><span>Pair</span><span>Side</span><span>Price</span><span>Value</span></div>{trades.length ? trades.map(t => <div className="table-row trade-cols" key={t.id}><span>{time(t.time)}</span><strong>{t.productId}</strong><span className={`text-${t.side.toLowerCase()}`}>{t.side}</span><span>{money(t.price)}</span><b>{money(t.value)}</b></div>) : <Empty text="No trades yet." />}</div></div></div> }

function Diagnostics({ data, logs }) { const checks = [['CORE ENGINE', !!data], ['MARKET FEED', !!data?.feedStats?.connected], ['PRICE STREAM', Object.keys(data?.lastPrices || {}).length > 0], ['STRATEGY ENGINE', !!data?.strategyName], ['PAPER EXECUTION', !!data?.paperTrade]]; return <div className="page-stack"><div className="diagnostic-grid"><div className="panel"><div className="panel-head"><div><span className="eyebrow">KITT SYSTEM</span><h2>Diagnostics</h2></div></div>{checks.map(([name, ok]) => <div className="health-row" key={name}><span className={ok ? 'health-dot ok' : 'health-dot'} />{name}<b>{ok ? 'HEALTHY' : 'WAITING'}</b></div>)}</div><div className="panel"><div className="panel-head"><div><span className="eyebrow">EVENT TIMELINE</span><h2>Live Logs</h2></div></div><div className="logs">{logs.length ? logs.map((l, i) => <div className="log-line" key={`${l.time}-${i}`}><time>{l.time}</time><span>{l.msg}</span></div>) : <Empty text="No events recorded." />}</div></div></div></div> }

function Backup() { const download = () => { window.location.href = '/api/backup/download' }; return <div className="page-stack"><div className="backup-hero"><div className="backup-icon">↻</div><span className="eyebrow">RECOVERY & EXPORT</span><h2>Backup Center</h2><p>Download the current project backup through the existing backend endpoint.</p><button className="primary" onClick={download}>Download backup</button></div><div className="panel"><div className="panel-head"><h2>Recommended workflow</h2></div><div className="backup-steps"><span>01</span><div><b>Stop the engine</b><small>Keep the paper session stable before exporting.</small></div><span>02</span><div><b>Download backup</b><small>Use the backend backup endpoint above.</small></div><span>03</span><div><b>Copy the project folder</b><small>Keep an external snapshot of the whole workspace.</small></div></div></div></div> }

export default App

# Backend kapcsolat

A jelenlegi MancsBot motor továbbra is Node.js/Express folyamatként fut.

## PC / szerver

1. Indítsd a `coinbase-paper-trader` backendet a 3000-es porton.
2. Nézd meg a gép helyi IP-címét (példa: `192.168.1.20`).
3. Az APK-ban koppints a **⚙** gombra.
4. Írd be: `http://192.168.1.20:3000`.

A backend már tartalmaz CORS fejléceket, ezért a mobil WebView API-kérései engedélyezhetők.

## Biztonság

Nyilvános interneten ne tedd ki védelem nélkül a trading API-t. Használj HTTPS-t, hitelesítést és tűzfalszabályokat. Coinbase titkos kulcsot soha ne tárolj az APK-ban.

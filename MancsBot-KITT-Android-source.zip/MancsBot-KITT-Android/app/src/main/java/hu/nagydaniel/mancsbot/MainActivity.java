package hu.nagydaniel.mancsbot;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "mancsbot_settings";
    private static final String KEY_BACKEND = "backend_base";
    private static final String START_URL = "file:///android_asset/www/index.html";

    private WebView webView;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(7, 10, 14));
        window.setNavigationBarColor(Color.rgb(7, 10, 14));

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(7, 10, 14));

        webView = createWebView();
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView settingsButton = createSettingsButton();
        FrameLayout.LayoutParams settingsParams = new FrameLayout.LayoutParams(dp(50), dp(50));
        settingsParams.gravity = Gravity.END | Gravity.BOTTOM;
        settingsParams.setMargins(0, 0, dp(16), dp(18));
        root.addView(settingsButton, settingsParams);

        View splash = createSplash();
        root.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);
        webView.loadUrl(START_URL);

        handler.postDelayed(() -> {
            splash.animate()
                    .alpha(0f)
                    .setDuration(350)
                    .withEndAction(() -> {
                        ((ViewGroup) splash.getParent()).removeView(splash);
                        if (getBackendBase().isEmpty()) {
                            showBackendDialog(true);
                        }
                    })
                    .start();
        }, 2200);
    }

    @SuppressWarnings("deprecation")
    private WebView createWebView() {
        WebView view = new WebView(this);
        view.setBackgroundColor(Color.rgb(7, 10, 14));

        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(s.getUserAgentString() + " MancsBotKITT-Android/1.0");

        view.addJavascriptInterface(new AndroidBridge(), "KittAndroid");
        view.setWebChromeClient(new WebChromeClient());
        view.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                return handleNavigation(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return handleNavigation(Uri.parse(url));
            }
        });
        return view;
    }

    private boolean handleNavigation(Uri uri) {
        String url = uri == null ? "" : uri.toString();
        if (url.contains("/api/backup/download")) {
            String backend = getBackendBase();
            if (backend.isEmpty()) {
                showBackendDialog(false);
            } else {
                openExternal(backend + "/api/backup/download");
            }
            return true;
        }
        if (url.startsWith("http://") || url.startsWith("https://")) {
            openExternal(url);
            return true;
        }
        return false;
    }

    private TextView createSettingsButton() {
        TextView button = new TextView(this);
        button.setText("⚙");
        button.setTextColor(Color.rgb(231, 237, 242));
        button.setTextSize(24);
        button.setGravity(Gravity.CENTER);
        button.setElevation(dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.rgb(16, 22, 29));
        bg.setStroke(dp(1), Color.rgb(53, 66, 76));
        button.setBackground(bg);
        button.setContentDescription("Backend beállítás");
        button.setOnClickListener(v -> showBackendDialog(false));
        return button;
    }

    private View createSplash() {
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.rgb(7, 10, 14));

        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER_HORIZONTAL);
        column.setPadding(dp(28), dp(32), dp(28), dp(32));

        TextView logo = new TextView(this);
        logo.setText("K");
        logo.setTextColor(Color.rgb(157, 252, 88));
        logo.setTextSize(42);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setGravity(Gravity.CENTER);
        GradientDrawable logoBg = new GradientDrawable();
        logoBg.setShape(GradientDrawable.RECTANGLE);
        logoBg.setCornerRadius(dp(18));
        logoBg.setColor(Color.rgb(16, 22, 29));
        logoBg.setStroke(dp(1), Color.rgb(89, 125, 66));
        logo.setBackground(logoBg);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(84), dp(84));
        logoParams.bottomMargin = dp(20);
        column.addView(logo, logoParams);

        TextView title = text("KITT MANCSBOT", 23, Color.rgb(231, 237, 242), true);
        title.setLetterSpacing(0.08f);
        column.addView(title);

        TextView sub = text("ANDROID COMMAND CENTER", 11, Color.rgb(97, 230, 255), true);
        sub.setLetterSpacing(0.14f);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        subParams.topMargin = dp(7);
        subParams.bottomMargin = dp(34);
        column.addView(sub, subParams);

        TextView author = text("Készítette: Nagy Dániel", 14, Color.rgb(231, 237, 242), true);
        column.addView(author);

        TextView legal = text(
                "© 2026 Nagy Dániel. Minden jog fenntartva.\n" +
                "Az alkalmazás és annak tartalma engedély nélküli másolása, módosítása vagy terjesztése tilos.",
                10,
                Color.rgb(111, 124, 136),
                false);
        legal.setGravity(Gravity.CENTER);
        legal.setLineSpacing(0, 1.25f);
        LinearLayout.LayoutParams legalParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        legalParams.topMargin = dp(12);
        column.addView(legal, legalParams);

        FrameLayout.LayoutParams columnParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        columnParams.gravity = Gravity.CENTER;
        overlay.addView(column, columnParams);
        overlay.setClickable(true);
        return overlay;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private void showBackendDialog(boolean firstRun) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("http://192.168.1.20:3000");
        input.setText(getBackendBase());
        input.setSelectAllOnFocus(false);
        input.setPadding(dp(16), dp(10), dp(16), dp(10));

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(22), dp(8), dp(22), 0);

        TextView help = new TextView(this);
        help.setText("Add meg a KITT Node backend címét. Telefon és szerver legyen ugyanazon a hálózaton, vagy használj HTTPS címet.\n\nPélda: http://192.168.1.20:3000");
        help.setTextColor(Color.DKGRAY);
        help.setTextSize(13);
        help.setPadding(0, 0, 0, dp(10));
        wrap.addView(help);
        wrap.addView(input);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("KITT backend kapcsolat")
                .setView(wrap)
                .setPositiveButton("Mentés", null)
                .setNeutralButton("Törlés", null)
                .setNegativeButton(firstRun ? "Később" : "Mégse", null)
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String normalized = normalizeBackend(input.getText().toString());
                if (normalized == null) {
                    input.setError("http:// vagy https:// kezdetű címet adj meg.");
                    return;
                }
                prefs.edit().putString(KEY_BACKEND, normalized).apply();
                Toast.makeText(this, "Backend mentve: " + normalized, Toast.LENGTH_SHORT).show();
                webView.reload();
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                prefs.edit().remove(KEY_BACKEND).apply();
                webView.reload();
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    private String normalizeBackend(String raw) {
        String value = raw == null ? "" : raw.trim();
        while (value.endsWith("/")) value = value.substring(0, value.length() - 1);
        if (value.isEmpty()) return "";
        if (!(value.startsWith("http://") || value.startsWith("https://"))) return null;
        return value;
    }

    private String getBackendBase() {
        return prefs == null ? "" : prefs.getString(KEY_BACKEND, "");
    }

    private void openExternal(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "Nem nyitható meg: " + url, Toast.LENGTH_LONG).show();
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private class AndroidBridge {
        @JavascriptInterface
        public String getBackendBase() {
            return MainActivity.this.getBackendBase();
        }

        @JavascriptInterface
        public void openBackendSettings() {
            runOnUiThread(() -> showBackendDialog(false));
        }

        @JavascriptInterface
        public String getAuthor() {
            return "Nagy Dániel";
        }
    }
}
